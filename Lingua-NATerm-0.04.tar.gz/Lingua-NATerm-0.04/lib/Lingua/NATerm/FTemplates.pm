package Lingua::NATerm::FTemplates;

use warnings;
use strict;
use Data::Dumper;

our(@ISA,@EXPORT);
our $VERSION = '0.01';
my $debug=0;

our %k=();            ## templateId -> template
our %default=();      ## templateId -> (var -> value|CODE)
our %sig=();          ## templateId -> (var -> type ) | (_order -> var*)
my $id = qr{[\w-]+};  ## identifier regexp
my ($OT,$CT);         ## open / close tags regexp

BEGIN{
  require Exporter;
  @ISA = qw(Exporter);
  our @EXPORT = qw(skzip skzipl skimport mkftemplateskel );
  $OT = qr{\[\%\s*};
  $CT = qr{\s*\%\]};
}

sub skzipl{ @{ skzip(@_)}} 
sub skzip{ my ($a,$b)=@_;
 if(ref($b) eq "ARRAY"){  [map {[$a->[$_],$b->[$_]]} 0..@$a-1] }
 else                  {  [map {[$a->[$_],$b]} 0..@$a-1] }
}

sub _sk{                       ## templateId, ($hash-hand)*
 my ($t,@handle)= @_;          ## templateId, ($array-hand)*  (using sig _order)
 @handle =([]) unless @handle;

 my $res=""; 
 for my $han (@handle){
  my $temp=$k{$t};
  die("no Skell $t\n") unless defined $temp;
  if(not ref($han)){ $han = [$han] }
  if(ref($han) eq "ARRAY"){ $han = 
      +{ map { ($sig{$t}{_order}[$_]=>$han->[$_], $_+1=>$han->[$_]) } (0..@$han-1)}}
  
  my $nov=1;
  while($nov){
   $nov =0;
   $nov += ($temp =~ s/${OT} !($id)          $CT /$k{$1}/gx);
   $nov += ($temp =~ s/${OT} INCLUDE\s+($id) $CT /$k{$1}/gx);
   $nov += ($temp =~ s/${OT} ($id)           $CT /_opatom($t,$1,$han)/gxe);
   $nov += ($temp =~ s/${OT} ($id)\*($id)    $CT /_sk($2,@{_opstar($t,$1,$han)})/gxe);
   $nov += ($temp =~ s/${OT} ($id)\*($id)\(sep:(.*?)\)$CT/
       join($3, map {_sk($2,$_)} @{_opstar($t,$1,$han)})/gxe);
  }
  $res .= $temp
 }
 $res;
}

sub _opstar{ my $r = _op(@_);
  if(ref($r) eq "ARRAY") { return $r }
  else                   { return [$r] }
}

sub _opatom{ my $r = _op(@_);
  if(ref($r) eq "ARRAY") { return join("",@$r) }
  else                   { return $r }
}

sub _op{    ## templateId, varName, Handler
  my ($k,$n,$h)=@_;
##  print STDERR "=====\n$k/$n\n",Dumper($h);
  return $h->{$n}(_n => $n,%$h)  if(defined $h->{$n} and ref($h->{$n}) eq "CODE");
  return $h->{$n}                if(defined $h->{$n} and ref($h->{$n}) eq "ARRAY");
  return $h->{$n}                if(defined $h->{$n}                          ); 
  return $default{$k}{$n}(_n=>$n,%$h) 
                                 if(defined $default{$k}{$n} and ref($default{$k}{$n}) eq "CODE");
  return $default{$k}{$n}        if(defined $default{$k}{$n});
  return _sk($n,$h)              if(defined $k{$n});
  return $h->{-default}(_n=>$n,%$h) if(ref $h->{-default} eq "CODE");
  return $h->{-default}          if(defined $h->{-default});
  return "$n???"             ;
}

sub _opl{
  my ($k1,$k2,%h)=@_;
  print STDERR "OPL:$k1,$k2","\n" if $debug ;
  return "$k1???*$k2"   if(not defined $h{$k1});
  return "$k1*$k2???"   if(not defined $k{$k2});
  return "$k1*$k2?2?"   if(ref($h{$k1}) ne "ARRAY");
  return join("", map { _sk($k2, 1 => $_) } @{$h{$k1}});
}

sub _skinit{ my @a=@_;
 my $SKEL;

 $a[0] //= ".";
 if(@a){ 
     if($a[0] eq "."){ $a[0] = (caller(1))[1]; }
     for my $file(@a){
            open(F,"<",$file) or print STDERR "Cant open '$file'($!)\n"; 
            $SKEL.="\n__IGNORE__\n\n".join("",<F>);
            close F;}}
 else  {
     $SKEL = join("",<main::DATA>);}

 if(0){ print main::DATA, "trying to avoid 'used only once'";}

 $SKEL =~ s/\n__DATA__\n__/\n__DATA__\n\n__/; ## dirty hacking 

 while($SKEL =~ s/__(.*)__\n((.|\n)*?)(?:(?=\n__.*__)|$)//){
   next if $1 eq "DATA" || $1 eq "END" || $1 eq "IGNORE";
   $k{$1}=$2 ;
   $k{$1}=~ s/\n\\(__.*__)/\n$1/g ;
 }

 my $changes=1;
 while($changes){$changes=0;
   for(keys %k){ 
      $changes += ($k{$_} =~ s/$OT!($id)$CT/$k{$1}/g); 
      if($k{$_} =~ s/$OT(?:default:)(.*?)$CT//s){ $default{$_}=eval($1);}
   }
 }
 for my $k (keys %k){ 
   $sig{$k}{_order}=[];
   my $t=$k{$k};
   while($t =~ m/$OT($id)$CT/g){ 
      push(@{$sig{$k}{_order}},$1) unless  $sig{$k}{$1};
      $sig{$k}{$1}="atomic";
   }
   while($t =~ m/$OT($id)\*($id)\(.*?\)$CT/g){ $sig{$k}{$1}="list($2)";}
   while($t =~ m/$OT($id)\*($id)$CT/g){ $sig{$k}{$1}="list($2)";}
 }
}

sub skimport{
 %k=();
 @EXPORT =();
 _skinit(@_);
 my $class;
 print STDERR "skimport exporting: (",join(",",keys %k), ")=\n" if $debug;

 for my $fun(keys %k){
   no strict 'refs';  
   *$fun = sub{ _sk($fun,@_) || undef; }; 
   push (@EXPORT,$fun);
 }
 print STDERR "skimport exporting : (",join(",",@EXPORT), ")=\n" if $debug;
 Lingua::NATerm::FTemplates->export_to_level(1, $class, @EXPORT);
}

sub mkftemplateskel{
 my %opt =(ignore => []);
 if(ref($_[0]) eq "HASH") {%opt = (%opt , %{shift(@_)}) } ;
 my $r="";
 _skinit(@_);
 my %ign = map {($_ => $_)} @{$opt{ignore}};
 for my $k(keys %k){
   next if $k eq "SK";
   next if $ign{$k};
   $r .= "# $k({";
   for(keys %{$sig{$k}}){
       next if /_order/;
       if($sig{$k}{$_} eq "atomic") { 
          $r.= "\n#\t$_ => '__',";}
       elsif($sig{$k}{$_} =~ m{list\((.*?)\)} ) { 
          $r.= "\n#\t$_ => [['". join(", ",@{$sig{$1}{_order}})."'],[...]] ,";}
       else                        { $r.= "\n#\t$_ => [ '__$sig{$k}{$_}'] ,";}
     }
   $r.= "});\n\n";
   ## $r .= "## ".join(" ",@{$sig{$k}{_order}})."\n";
 }
 $r
}

1; # End of FTemplates

__END__

=head1 NAME

Lingua::NATerm::FTemplates - Build and use templates stored in __DATA__ (or file)

=head1 VERSION

Version 0.01

=head1 SYNOPSIS

    use Lingua::NATerm::FTemplates ;
    skimport();
    Template1(...)
    ...
    __DATA__

    __Template1__

    __Template2__

    __END__

=head1 EXPORT

=head1 SUBROUTINES/METHODS

=head2 skimport

With C<skimport> you get a function for each template available

 skimport()     -- import templates from __DATA__  
 skimport(file) -- import templates from file

for each template:

 template(handler*)

=head1 Handers

Each hander is HASH-ref mapping a id to a value, a CODE-ref

 [% title %]       is replaced by $handler->{title}
                   or             $handler->{title}()

Alternatively a handler can be a ARRAY-ref and it will correspond
the the field in the order they appear in the template.

=head1 Auxiliar functions

=head2 mkftemplateskel

Generates a skeleton of the perl processor of a template
(see mkftemplateskel script)

=head2 skzip

Zip 2 ARRAY in a single ARRAY of ARRAY

 skzip([1,2,3],[4,5,6]) ---> [[1,4],[2,5],[3,6]]
 skzip([1,2,3], 20) ---> [[1,20],[2,20],[3,20]]

=head2 skzipl

Zip 2 ARRAY in a single list of ARRAY

 skzipl($l1, $l2) = @{skzip($l1,$l2)}

=head1 Format of template

 __DATA__

 __Template1__

 ... [%title%]                   // expand with $handler{title}
 ... [%!Template2%]              // include template "Template2"
 ... [% INCLUDE Template2%]      // include template "Template2"
 ... [%line*Template%]          // for all x in @handler{line} 
                 // aply template "Template(x)"
 ... [%line*Template(sep:,)%]   // for all x in @ handler{line} 
                 // aply template "Template(x)" and join with ","
 ... [%default:{var=>value...}%] // define default values var; value can use
                 // the other values

 __Template2__

 __END__
 ...

The C<default> section is calculated (eval) at skimport time. So if a
calculation depends on the other values, a CODE ref should be used.
These functions receive the provided values as a parameter (HASH of values). 

Example: calculate a full_title, processing the title, author and date. This 
way if a full_title is provided, it is used directl; otherwise it is 
computed from title, author and date.

 [% default:{
   full_title => sub{ my %a=@_;
      my $d= $a{date}     || '\today';
      my $s= $a{author}   || '\mbox{}';
      qq{\\exametitle{$a{title}}{$s}{$d}}}
 } %]

=head1 AUTHOR

J.Joao, C<< <jj at di.uminho.pt> >>

=head1 LICENSE AND COPYRIGHT

Copyright 2012 J.Joao.

This program is free software; you can redistribute it and/or modify it
under the terms of either: the GNU General Public License as published
by the Free Software Foundation; or the Artistic License.

See http://dev.perl.org/licenses/ for more information.

=cut

