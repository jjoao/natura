package Lingua::NATerm;

use strict;
use warnings;

require Exporter;

our @ISA = qw(Exporter);

our %EXPORT_TAGS = ( 'all' => [ qw( ) ] );
our @EXPORT_OK = ( @{ $EXPORT_TAGS{'all'} } );
our @EXPORT = qw( );

our $VERSION = '0.04';


# Preloaded methods go here.

1;
__END__

=head1 NAME

Lingua::NATerm - Perl extension ...

=head1 SYNOPSIS

  use Lingua::NATerm;
  ...

=head1 DESCRIPTION

=head2 EXPORT

=head1 SEE ALSO

  naterm  - command

=head1 AUTHOR

jjoao Dias de ALmeida, E<lt>jj@E<gt>

=head1 COPYRIGHT AND LICENSE

Copyright (C) 2013 by jjoao Dias de ALmeida

=cut
